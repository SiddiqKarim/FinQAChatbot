# Libraries

from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
import nltk
import re
import nltk
nltk.download('stopwords')
stopwords = nltk.corpus.stopwords.words('english')
import torch
import spacy
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer


#from transformers import BertTokenizer, BertForSequenceClassification

#import language_tool_python

#tool = language_tool_python.LanguageToolPublicAPI('en-US') # or use public API
#tool.correct('A santence with a eror in the Hitchhiker’s  revnue Gide tot he Galaxy')

# Load SpaCy English language model
nlp = spacy.load("en_core_web_sm")

# Define the available details in your dataset
available_details = {
    #'Year': [2009, 2010, 2011, 2020],
    #'Company': ['AAPL', 'Microsoft', 'Apple','MSFT', 'TATA','BMO', 'Scotia Bank'],
    #'Category': ['IT', 'Construction'],
    'Market Cap(in B USD)': [],  # Add other details as needed
    'Revenue': [],
    'Gross Profit': [],
    'Net Income': [],
    'Earning Per Share': [],
    'EBITDA': [],
    'Share Holder Equity': [],
    'Cash Flow from Operating': [],
    'Cash Flow from Investing': [],
    'Cash Flow from Financial Activities': [],
    'Current Ratio': [],
    'Debt/Equity Ratio': [],
    'ROE': [],
    'ROA': [],
    'ROI': [],
    'Net Profit Margin': [],
    'Free Cash Flow per Share': [],
    'Return on Tangible Equity': [],
    'Number of Employees': [],
    'Inflation Rate(in US)': []
}


# Import Necessary files
df = pd.read_csv("Financial.csv")
df_mp = pd.read_excel("qa.xlsx")
qa_data = ""

# pre Process the data

def preprocess_text(text):
    doc = nlp(text)
    lemmas = [token.lemma_ for token in doc]
    lemmas_without_stopwords = [lemma for lemma in lemmas if lemma.lower() not in stopwords and lemma.isalpha()]

    return ' '.join(lemmas_without_stopwords)

# Loading the dataset

def load_database(numbers_to_text=True):
    global knowledge_base
    global vec_kbase
    
    
    #if numbers_to_text:
    #    df_mp['question'] = df_mp['question'].apply(transcribe_numbers)

    df_mp['processed_texts'] = df_mp['question'].apply(preprocess_text)
    #print("details:",df_mp['processed_texts'])    
    qa_data = qa_data['processed_texts'].tolist()

# Cosine Similarity

def get_C_distance(user_question, numbers_to_text=True):
    
    import numpy as np
    from sklearn.feature_extraction.text import TfidfVectorizer
    
    #if numbers_to_text:
    #    df_mp['question'] = df_mp['question'].apply(transcribe_numbers)

    df_mp['processed_texts'] = df_mp['question'].apply(preprocess_text)
    #print("details:",df_mp['processed_texts'])    

    qa_data = df_mp['processed_texts'].tolist()
    
    #print("data", qa_data)
    if numbers_to_text:
        user_question = preprocess_text(user_question)
                                         
    user_text_processed = preprocess_text(user_question)
    
    vectorizer = TfidfVectorizer()
    
    bow_matrix = vectorizer.fit_transform(qa_data + [user_text_processed])

    cosine_distances = cosine_similarity(bow_matrix[-1], bow_matrix[:-1])
   
    max_distance_index = cosine_distances.argmax()
     
    df_mp['distances'] = cosine_distances.flatten().tolist()

    return df_mp['question'].iloc[max_distance_index], df_mp['location'].iloc[max_distance_index], df_mp['distances'].iloc[max_distance_index]


# OUTPUT

# Function to extract company name and year explicitly from the user question
import string
def extract_company_and_year(sentence):
    # Process the sentence using SpaCy
    doc = nlp(sentence)
    # Extract company name
    companies = [ent.text.upper() for ent in doc.ents if ent.label_ == "ORG"]
    #for ent in doc.ents:
      #print("text",ent.text)
      #print("label",ent.label_)

    return companies

# Function to extract company name and year explicitly from the user question
def extract_and_year(sentence):
    # Process the sentence using SpaCy
    doc = nlp(sentence)
    # Extract year and int(token.text) in available_details['Year']
    years = [token.text for token in doc if token.text.isdigit()]

    return  years

def fun_revenue(company_name, year_name, available_details_mentioned):

    # Filter the DataFrame based on the company name and year
    filtered_df = df[(df['Company'] == company_name[0]) & (df['Year'] == int(year_name[0]))]
    # Check if any data is available after filtering
    if filtered_df.empty:
        '''if df['Company'] != company_name & df['Year'] == int(year_name):
          return "The "+ company_name+ " company is not available in our database so You have to select from our company list."
        elif df['Company'] == company_name & df['Year'] != int(year_name):
          return "The "+ company_name+ " company finanacailreport is Just avilable betweeen 2009 to 2022 as your provided"+year_name+" is not in our database ."
        '''
        return "No data available for " + company_name[0] + " in " + str(year_name) + "."
    else:
        # Extract the revenue value
        value_detail = float(filtered_df[available_details_mentioned].iloc[0])  # Assuming 'Revenue' is the column name
        return value_detail


while True:
    response_text =""
    # Get a question from the user
    user_question = input("USER: ")
    match, location, distance = get_C_distance(user_question)
  
    # Check if the user wants to exit
    if user_question.lower() == "bye":
        print("Goodbye!")
        break

    else:    # Extract company name based on intent
        if location == "fun_revenue":
          
          company_name = extract_company_and_year(user_question)

            # Extract year based on intent
          year_name = extract_and_year(user_question)

            # Identify the available details mentioned in the user question
          
          available_details_mentioned = [detail for detail in available_details if detail.lower() in user_question.lower()]

            # Retrieve financial details for the specified company and year
          result = fun_revenue(company_name, year_name, available_details_mentioned)
          print("Chat BOT:", result)
        else:
          
          print("Chat BOT:", str(location))